const STORAGE_KEY = "buk_screening_frontend_v1";
let state = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null") || {
  user: null,
  loggedIn: false,
  profile: {},
  nextkin: {},
  academic: {},
  documents: {},
  payment: { status: "Pending", amount: "", reference: "" }
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function toast(message) {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}

function showView(name) {
  $$(".view").forEach(v => v.classList.remove("active"));
  const target = $(`#${name}View`);
  if (target) target.classList.add("active");

  $$(".nav-link").forEach(btn => btn.classList.toggle("active", btn.dataset.view === name));
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function normalizeJamb(value) {
  return value.trim().toUpperCase().replace(/\s+/g, "");
}

function requireLogin() {
  if (!state.loggedIn || !state.user) {
    showView("login");
    toast("Please login to continue.");
    return false;
  }
  return true;
}

function calculateProgress() {
  const sections = [
    Object.keys(state.profile).length > 3,
    Object.keys(state.nextkin).length > 2,
    Object.keys(state.academic).length > 3,
    Object.keys(state.documents).length >= 1,
    state.payment.status === "Paid"
  ];
  const completed = sections.filter(Boolean).length;
  return Math.round((completed / sections.length) * 100);
}

function updateDashboard() {
  if (!state.user) return;
  const displayName = state.profile.firstName
    ? `${state.profile.firstName} ${state.profile.surname || ""}`.trim()
    : "Candidate";
  $("#dashName").textContent = `Welcome, ${displayName}`;
  $("#dashJamb").textContent = `JAMB Registration Number: ${state.user.jamb}`;
  const progress = calculateProgress();
  $("#progressText").textContent = `${progress}%`;
  $("#progressBar").style.width = `${progress}%`;
}

function renderSection(section) {
  if (!requireLogin()) return;

  const titles = {
    personal: ["Personal Information", "Complete your biodata and contact information."],
    nextkin: ["Next of Kin / Emergency Contact", "Provide a person who can be contacted when necessary."],
    academic: ["Academic Information", "Provide your programme and O'Level information."],
    documents: ["Document Upload", "Upload clear copies of the required screening documents."],
    payment: ["Payment", "View your payment status. Production payment verification must be connected to the authorized payment backend."],
    ack: ["Acknowledgement Slip", "Your acknowledgement slip becomes available after the required steps are completed."]
  };
  $("#sectionEyebrow").textContent = section.replace("-", " ");
  $("#sectionTitle").textContent = titles[section][0];
  $("#sectionDescription").textContent = titles[section][1];

  const content = $("#sectionContent");
  if (section === "personal") {
    content.innerHTML = `
      <form id="personalForm" class="card form-card">
        <div class="form-grid">
          <label class="field"><span>Surname *</span><input name="surname" required value="${esc(state.profile.surname || "")}"></label>
          <label class="field"><span>First Name *</span><input name="firstName" required value="${esc(state.profile.firstName || "")}"></label>
          <label class="field"><span>Other Names</span><input name="otherNames" value="${esc(state.profile.otherNames || "")}"></label>
          <label class="field"><span>Date of Birth *</span><input name="dob" type="date" required value="${esc(state.profile.dob || "")}"></label>
          <label class="field"><span>Gender *</span><select name="gender" required>${options(["","Male","Female"], state.profile.gender)}</select></label>
          <label class="field"><span>State of Origin *</span><input name="state" required value="${esc(state.profile.state || "")}"></label>
          <label class="field"><span>LGA *</span><input name="lga" required value="${esc(state.profile.lga || "")}"></label>
          <label class="field"><span>Phone Number *</span><input name="phone" required value="${esc(state.profile.phone || state.user.phone || "")}"></label>
          <label class="field"><span>Email Address *</span><input name="email" type="email" required value="${esc(state.profile.email || state.user.email || "")}"></label>
          <label class="field full"><span>Contact Address *</span><textarea name="address" required>${esc(state.profile.address || "")}</textarea></label>
        </div>
        <div class="form-actions"><button type="submit" class="btn btn-primary">Save & Continue</button></div>
      </form>`;
  } else if (section === "nextkin") {
    content.innerHTML = `
      <form id="nextkinForm" class="card form-card">
        <div class="form-grid">
          <label class="field"><span>Full Name *</span><input name="name" required value="${esc(state.nextkin.name || "")}"></label>
          <label class="field"><span>Relationship *</span><input name="relationship" required value="${esc(state.nextkin.relationship || "")}" placeholder="e.g. Father"></label>
          <label class="field"><span>Phone Number *</span><input name="phone" required value="${esc(state.nextkin.phone || "")}"></label>
          <label class="field full"><span>Address *</span><textarea name="address" required>${esc(state.nextkin.address || "")}</textarea></label>
        </div>
        <div class="form-actions"><button type="submit" class="btn btn-primary">Save & Continue</button></div>
      </form>`;
  } else if (section === "academic") {
    content.innerHTML = `
      <form id="academicForm" class="card form-card">
        <div class="form-grid">
          <label class="field"><span>UTME Score *</span><input name="utmeScore" type="number" min="0" max="400" required value="${esc(state.academic.utmeScore || "")}"></label>
          <label class="field"><span>Entry Mode *</span><select name="entryMode" required>${options(["","UTME","Direct Entry"], state.academic.entryMode)}</select></label>
          <label class="field"><span>Faculty *</span><input name="faculty" required value="${esc(state.academic.faculty || "")}"></label>
          <label class="field"><span>Programme *</span><input name="programme" required value="${esc(state.academic.programme || "")}"></label>
          <label class="field"><span>O'Level Exam *</span><select name="olevelExam" required>${options(["","WAEC","NECO","NABTEB","NBAIS","Other"], state.academic.olevelExam)}</select></label>
          <label class="field"><span>O'Level Exam Number *</span><input name="olevelNumber" required value="${esc(state.academic.olevelNumber || "")}"></label>
          <label class="field full"><span>O'Level Grades / Subjects *</span><textarea name="olevelGrades" required placeholder="Example: English - B3, Mathematics - C4...">${esc(state.academic.olevelGrades || "")}</textarea></label>
        </div>
        <div class="form-actions"><button type="submit" class="btn btn-primary">Save Academic Information</button></div>
      </form>`;
  } else if (section === "documents") {
    content.innerHTML = `
      <div class="card form-card">
        <div class="upload-box"><strong>JAMB Slip</strong><small>Accepted: JPG, PNG, PDF. Production limits should be enforced server-side.</small><input data-doc="jambSlip" type="file" accept=".jpg,.jpeg,.png,.pdf"></div>
        <div class="upload-box"><strong>JAMB Admission Letter</strong><small>Upload a clear copy.</small><input data-doc="admissionLetter" type="file" accept=".jpg,.jpeg,.png,.pdf"></div>
        <div class="upload-box"><strong>O'Level Result</strong><small>Upload a clear copy.</small><input data-doc="olevelResult" type="file" accept=".jpg,.jpeg,.png,.pdf"></div>
        <div class="upload-box"><strong>A'Level Result (DE where applicable)</strong><small>Optional for UTME candidates.</small><input data-doc="alevelResult" type="file" accept=".jpg,.jpeg,.png,.pdf"></div>
        <div id="docStatus"></div>
        <div class="form-actions"><button id="saveDocs" class="btn btn-primary">Save Document Status</button></div>
      </div>`;
    updateDocStatus();
  } else if (section === "payment") {
    const paid = state.payment.status === "Paid";
    content.innerHTML = `
      <div class="card form-card">
        <div class="notice">
          <div class="notice-icon">₦</div>
          <div><strong>Payment status</strong><p>Current status: <span class="status ${paid ? "success" : "warning"}">${esc(state.payment.status)}</span></p></div>
        </div>
        <table class="data-table">
          <tr><th>Payment Type</th><td>Screening / Registration</td></tr>
          <tr><th>Amount</th><td>${state.payment.amount ? "₦" + esc(state.payment.amount) : "Not generated"}</td></tr>
          <tr><th>Reference</th><td>${esc(state.payment.reference || "Not generated")}</td></tr>
        </table>
        <p class="muted">This frontend does not process or fake payments. Connect the button to an authorized payment gateway and verify transactions server-side.</p>
        <div class="form-actions"><button id="demoPayment" class="btn btn-outline">Demo: Mark Paid Locally</button></div>
      </div>`;
    $("#demoPayment").addEventListener("click", () => {
      state.payment = { status: "Paid", amount: "0", reference: "DEMO-" + Date.now() };
      save(); toast("Demo payment marked as paid locally."); renderSection("payment");
    });
  } else if (section === "ack") {
    const complete = calculateProgress() === 100;
    content.innerHTML = `
      <div class="card form-card">
        <div class="notice">
          <div class="notice-icon">${complete ? "✓" : "!"}</div>
          <div>
            <strong>${complete ? "Registration complete" : "Registration not yet complete"}</strong>
            <p>${complete ? "Your acknowledgement slip is ready in this prototype." : "Complete your profile, next of kin, academic information, documents and verified payment first."}</p>
          </div>
        </div>
        ${complete ? `
          <div id="slip" class="ack-slip">
            <h2>BAYERO UNIVERSITY, KANO</h2>
            <h3>UNDERGRADUATE SCREENING ACKNOWLEDGEMENT SLIP</h3>
            <hr>
            <p><strong>JAMB Number:</strong> ${esc(state.user.jamb)}</p>
            <p><strong>Name:</strong> ${esc((state.profile.surname || "") + " " + (state.profile.firstName || ""))}</p>
            <p><strong>Programme:</strong> ${esc(state.academic.programme || "")}</p>
            <p><strong>Faculty:</strong> ${esc(state.academic.faculty || "")}</p>
            <p><strong>Portal ID:</strong> ${esc(state.user.portalId)}</p>
            <p><strong>Status:</strong> COMPLETED</p>
          </div>
          <button id="printSlip" class="btn btn-primary">Print Acknowledgement Slip</button>
        ` : `<div class="empty">Use the dashboard cards to complete the remaining sections.</div>`}
      </div>`;
    if (complete) $("#printSlip").addEventListener("click", printSlip);
  }

  $("#sectionContent").querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", e => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      if (section === "personal") state.profile = { ...state.profile, ...data };
      if (section === "nextkin") state.nextkin = { ...state.nextkin, ...data };
      if (section === "academic") state.academic = { ...state.academic, ...data };
      save();
      toast("Information saved successfully.");
      updateDashboard();
      showView("dashboard");
    });
  });

  if ($("#saveDocs")) {
    $("#saveDocs").addEventListener("click", () => {
      $$("[data-doc]").forEach(input => {
        if (input.files[0]) state.documents[input.dataset.doc] = {
          name: input.files[0].name,
          size: input.files[0].size,
          status: "Pending Review"
        };
      });
      save(); updateDocStatus(); updateDashboard(); toast("Document status saved locally.");
    });
  }
}

function updateDocStatus() {
  const el = $("#docStatus");
  if (!el) return;
  const names = Object.keys(state.documents);
  if (!names.length) {
    el.innerHTML = `<div class="empty">No documents saved yet.</div>`;
    return;
  }
  el.innerHTML = `<table class="data-table"><thead><tr><th>Document</th><th>File</th><th>Status</th></tr></thead><tbody>
    ${names.map(k => `<tr><td>${pretty(k)}</td><td>${esc(state.documents[k].name)}</td><td><span class="status warning">${esc(state.documents[k].status)}</span></td></tr>`).join("")}
  </tbody></table>`;
}

function pretty(key) {
  return key.replace(/([A-Z])/g, " $1").replace(/^./, c => c.toUpperCase());
}

function options(values, selected) {
  return values.map(v => `<option value="${esc(v)}" ${v === selected ? "selected" : ""}>${esc(v || "Select")}</option>`).join("");
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[c]));
}

function printSlip() {
  const slip = $("#slip").innerHTML;
  const win = window.open("", "_blank", "width=800,height=900");
  win.document.write(`
    <html><head><title>Acknowledgement Slip</title>
    <style>body{font-family:Arial;padding:40px;line-height:1.7}h2,h3{text-align:center}hr{border:0;border-top:1px solid #ccc}</style>
    </head><body>${slip}</body></html>`);
  win.document.close();
  win.focus();
  win.print();
}

$$("[data-view]").forEach(btn => {
  btn.addEventListener("click", () => {
    const view = btn.dataset.view;
    if (view === "dashboard" && !requireLogin()) return;
    showView(view);
    if (view === "dashboard") updateDashboard();
  });
});

$$(".dash-card").forEach(card => {
  card.addEventListener("click", () => {
    renderSection(card.dataset.section);
    showView("section");
  });
});

$("#registerForm").addEventListener("submit", e => {
  e.preventDefault();
  const jamb = normalizeJamb($("#regJamb").value);
  const phone = $("#regPhone").value.trim();
  const email = $("#regEmail").value.trim();
  const pin = $("#regPin").value.trim();
  const pin2 = $("#regPinConfirm").value.trim();

  if (!jamb || !phone || !email || !pin) return toast("Please complete all required fields.");
  if (!/^\d{4,8}$/.test(pin)) return toast("PIN must contain 4–8 digits.");
  if (pin !== pin2) return toast("PIN confirmation does not match.");
  if (!$("#terms").checked) return toast("Please accept the declaration.");

  if (state.user && state.user.jamb === jamb) return toast("An account already exists for this JAMB number.");

  state.user = {
    jamb, phone, email,
    pin,
    portalId: "BUK-" + Math.random().toString(36).slice(2, 8).toUpperCase()
  };
  state.loggedIn = true;
  save();
  $("#registerForm").reset();
  toast("Account created. You are now logged in.");
  updateDashboard();
  showView("dashboard");
});

$("#loginForm").addEventListener("submit", e => {
  e.preventDefault();
  const jamb = normalizeJamb($("#loginJamb").value);
  const pin = $("#loginPin").value.trim();

  if (!state.user) return toast("No local account found. Please register first.");
  if (jamb !== state.user.jamb || pin !== state.user.pin) return toast("Invalid JAMB number or PIN.");

  state.loggedIn = true;
  save();
  toast("Login successful.");
  updateDashboard();
  showView("dashboard");
});

$("#logoutBtn").addEventListener("click", () => {
  state.loggedIn = false;
  save();
  showView("home");
  toast("You have been logged out.");
});

updateDashboard();
if (state.loggedIn) showView("dashboard");
